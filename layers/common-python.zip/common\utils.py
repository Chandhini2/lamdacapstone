@'
import json
from datetime import datetime, timezone

def json_log(msg: str, **kwargs) -> str:
    payload = {
        "msg": msg,
        "at": datetime.now(timezone.utc).isoformat()
    }
    payload.update(kwargs)
    return json.dumps(payload)
'@ | Set-Content "layers\common-python\python\common\utils.py"